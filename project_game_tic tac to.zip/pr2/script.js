let currentPlayer = "X";
let board = Array(9).fill("");
let gameActive = true;
let timer;
let timeLeft = 10;
let playerXName = "بازیکن X";
let playerOName = "AI";
let difficulty = "easy";
let gameMode = "ai"; // ai یا user

const mainMenu = document.getElementById("main-menu");
const gameModeSelection = document.getElementById("game-mode-selection");
const playerSelection = document.getElementById("player-selection");
const gameContainer = document.getElementById("game-container");
const cells = document.querySelectorAll(".cell");
const timerDisplay = document.getElementById("timer");
const currentPlayerName = document.getElementById("current-player-name");
const playerOInput = document.getElementById("player-o");

// نمایش منوی انتخاب نوع بازی
function showGameModeSelection() {
  mainMenu.classList.add("d-none");
  gameModeSelection.classList.remove("d-none");
}

// نمایش پنل انتخاب بازیکن
function showPlayerSelection(mode) {
  gameMode = mode;
  gameModeSelection.classList.add("d-none");
  playerSelection.classList.remove("d-none");

  if (mode === "ai") {
    playerOInput.style.display = "none";
    playerOName = "AI";
  } else {
    playerOInput.style.display = "block";
    playerOName = "بازیکن O";
  }
}

// شروع بازی
function startGame() {
  const playerXInput = document.getElementById("player-x").value.trim();
  const playerOInputValue = document.getElementById("player-o").value.trim();
  difficulty = document.getElementById("difficulty").value;

  if (!/^[A-Za-z]+$/.test(playerXInput) || (gameMode === "user" && !/^[A-Za-z]+$/.test(playerOInputValue))) {
    showAlert("نام بازیکن باید فقط شامل حروف لاتین باشد!", "warning");
    return;
  }

  playerXName = playerXInput || "بازیکن X";
  playerOName = gameMode === "ai" ? "AI" : playerOInputValue || "بازیکن O";
  playerSelection.classList.add("d-none");
  gameContainer.classList.remove("d-none");
  resetGame();
}

// تغییر تم
function toggleTheme() {
  document.body.classList.toggle("dark-mode");
  document.body.classList.toggle("light-mode");
}

// ریست بازی
function resetGame() {
  board = Array(9).fill("");
  cells.forEach(cell => cell.textContent = "");
  currentPlayer = "X";
  gameActive = true;
  timeLeft = 10;
  updateTimer();
  updateTurnDisplay();
  startTimer();
}

// بررسی برنده
function checkWinner() {
  const winningCombinations = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // ردیف‌ها
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // ستون‌ها
    [0, 4, 8], [2, 4, 6]             // قطرها
  ];

  for (let combo of winningCombinations) {
    const [a, b, c] = combo;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return board[a];
    }
  }

  if (!board.includes("")) return "draw";
  return null;
}

// شروع تایمر
function startTimer() {
  clearInterval(timer);
  timeLeft = 10;
  updateTimer();
  timer = setInterval(() => {
    timeLeft--;
    updateTimer();
    if (timeLeft <= 0) {
      clearInterval(timer);
      switchPlayer();
    }
  }, 1000);
}

// به‌روزرسانی تایمر
function updateTimer() {
  timerDisplay.textContent = `زمان باقی‌مانده: ${timeLeft} ثانیه`;
}

// تغییر بازیکن
function switchPlayer() {
  currentPlayer = currentPlayer === "X" ? "O" : "X";
  timeLeft = 10;
  updateTimer();
  updateTurnDisplay();
  startTimer();

  if (gameMode === "ai" && currentPlayer === "O") {
    computerMove();
  }
}

// به‌روزرسانی نمایش نوبت بازیکن
function updateTurnDisplay() {
  currentPlayerName.textContent = currentPlayer === "X" ? playerXName : playerOName;
}

// حرکت کامپیوتر بر اساس سطح دشواری
function computerMove() {
  let availableCells = board.map((val, idx) => val === "" ? idx : null).filter(val => val !== null);

  if (difficulty === "easy") {
    const randomIndex = availableCells[Math.floor(Math.random() * availableCells.length)];
    board[randomIndex] = "O";
    cells[randomIndex].textContent = "O";
  } else if (difficulty === "medium" || difficulty === "hard") {
    const bestMove = findBestMove();
    board[bestMove] = "O";
    cells[bestMove].textContent = "O";
  }

  const winner = checkWinner();
  if (winner) {
    gameActive = false;
    clearInterval(timer);
    if (winner === "draw") {
      showAlert("بازی مساوی شد!", "warning");
    } else {
      const winnerName = winner === "X" ? playerXName : playerOName;
      showAlert(`${winnerName} برنده شد!`, "success");
    }
  } else {
    switchPlayer();
  }
}

// منطق Minimax برای سطح سخت
function findBestMove() {
  let bestMove = -1;
  let bestScore = -Infinity;

  for (let i = 0; i < 9; i++) {
    if (board[i] === "") {
      board[i] = "O";
      let score = minimax(board, 0, false);
      board[i] = "";
      if (score > bestScore) {
        bestScore = score;
        bestMove = i;
      }
    }
  }

  return bestMove;
}

function minimax(board, depth, isMaximizing) {
  const result = checkWinner();
  if (result === "X") return -10 + depth;
  if (result === "O") return 10 - depth;
  if (result === "draw") return 0;

  if (isMaximizing) {
    let bestScore = -Infinity;
    for (let i = 0; i < 9; i++) {
      if (board[i] === "") {
        board[i] = "O";
        let score = minimax(board, depth + 1, false);
        board[i] = "";
        bestScore = Math.max(score, bestScore);
      }
    }
    return bestScore;
  } else {
    let bestScore = Infinity;
    for (let i = 0; i < 9; i++) {
      if (board[i] === "") {
        board[i] = "X";
        let score = minimax(board, depth + 1, true);
        board[i] = "";
        bestScore = Math.min(score, bestScore);
      }
    }
    return bestScore;
  }
}

// کلیک روی سلول
cells.forEach(cell => {
  cell.addEventListener("click", () => {
    if (!gameActive || board[cell.dataset.index] !== "") return;

    board[cell.dataset.index] = currentPlayer;
    cell.textContent = currentPlayer;

    const winner = checkWinner();
    if (winner) {
      gameActive = false;
      clearInterval(timer);
      if (winner === "draw") {
        showAlert("بازی مساوی شد!", "warning");
      } else {
        const winnerName = winner === "X" ? playerXName : playerOName;
        showAlert(`${winnerName} برنده شد!`, "success");
      }
    } else {
      switchPlayer();
    }
  });
});

// نمایش اعلان
function showAlert(message, type) {
  const alertDiv = document.createElement("div");
  alertDiv.className = `alert alert-${type}`;
  alertDiv.textContent = message;
  document.body.appendChild(alertDiv);

  setTimeout(() => {
    alertDiv.remove();
  }, 3000);
}